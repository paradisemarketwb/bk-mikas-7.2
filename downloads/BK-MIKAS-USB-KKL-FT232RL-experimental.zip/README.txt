USB-KKL / FT232RL — экспериментальная прошивка ESP32-S3

Сначала прочитайте USB-CONNECTION.md и USB-FLASH.md.
Полностью отключить R2-жгут: GPIO19 здесь USB D-, не TX_ARM.
KKL использует готовый USB-A female, 22 Ом в D-/D+ и внешний источник5V.
Прошивать ДИСПЛЕЙ через его USB TO UART/CH343 J2, не KKL и не nativeJ3.
Перед прошивкой KKL отключить от ПК/USB Host. Заменить COM7 портом дисплея.
Команда из ESP-IDF5.5.1 PowerShell, из распакованного каталога:

python -m esptool --chip esp32s3 -p COM7 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_size 16MB --flash_freq 80m 0x0 bootloader/bootloader.bin 0x8000 partition_table/partition-table.bin 0xe000 ota_data_initial.bin 0x10000 bk_mikas_r2.bin

Три сборки и host/KiCad CI прошли; физический KKL кESP32 здесь не подключался.
Сборка не подтверждает реальное USB enumeration и обмен с ЭБУ.
Полные исходники/документация: https://github.com/paradisemarketwb/bk-mikas-7.2
