BK R2 engineering prototype: separate BK-KLINE-R2 and BK-POWER-R2 boards.
Gerber/Excellon exported from real KiCad PCB files. BOM and positions included.
Check each board README before ordering. Electrical/thermal/vehicle qualification
and physical footprint confirmation remain required. Not a vehicle certification.
