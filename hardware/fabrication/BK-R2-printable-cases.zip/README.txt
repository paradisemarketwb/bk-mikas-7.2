BK R2 case sources and separate printable parts.
Use CAD README and verify dimensions on the actual Waveshare and assembled PCBs.
Closed STL mesh is not proof of physical fit, heat resistance or vibration strength.
